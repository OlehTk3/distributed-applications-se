using System.ComponentModel.DataAnnotations;

namespace DoctorAppointment.Domain
{
    public class Doctor
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(100)]
        public string FullName { get; set; }
        [Required]
        [MaxLength(100)]
        public string Specialization { get; set; }
        [MaxLength(20)]
        public string Phone { get; set; }
        public int ExperienceYears { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}