using System;
using System.ComponentModel.DataAnnotations;

namespace DoctorAppointment.Domain
{
    public class Patient
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(100)]
        public string FullName { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [MaxLength(20)]
        public string Phone { get; set; }
        [MaxLength(200)]
        public string Address { get; set; }
        public DateTime BirthDate { get; set; }
    }
}