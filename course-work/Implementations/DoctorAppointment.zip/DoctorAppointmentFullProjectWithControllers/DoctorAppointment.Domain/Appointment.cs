using System;
using System.ComponentModel.DataAnnotations;

namespace DoctorAppointment.Domain
{
    public class Appointment
    {
        public int Id { get; set; }
        [Required]
        public int PatientId { get; set; }
        [Required]
        public int DoctorId { get; set; }
        public DateTime Date { get; set; }
        [MaxLength(500)]
        public string Notes { get; set; }
        [MaxLength(50)]
        public string Status { get; set; }
        public Patient Patient { get; set; }
        public Doctor Doctor { get; set; }
    }
}