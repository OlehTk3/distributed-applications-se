﻿using DoctorAppointment.API.Models;
using Microsoft.EntityFrameworkCore;

namespace DoctorAppointment.API.Data
{
    public class DoctorAppointmentContext : DbContext
    {
        public DoctorAppointmentContext(DbContextOptions<DoctorAppointmentContext> options)
            : base(options)
        {
        }

        public DbSet<Patient> Patients { get; set; }
        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Appointment> Appointments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Дополнительные ограничения можно настроить здесь
            modelBuilder.Entity<Patient>()
                .Property(p => p.Gender)
                .IsFixedLength()
                .HasMaxLength(1);
        }
    }
}
