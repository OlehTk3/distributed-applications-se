﻿using System.ComponentModel.DataAnnotations;

namespace DoctorAppointment.API.Models
{
    public class Patient
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string LastName { get; set; } = string.Empty;

        [Required]
        public DateTime DateOfBirth { get; set; }

        [Required]
        [MaxLength(1)]
        public string Gender { get; set; } = string.Empty; // "M" или "F"

        [MaxLength(100)]
        public string? Address { get; set; }

        [Required]
        [MaxLength(15)]
        public string PhoneNumber { get; set; } = string.Empty;

        // Связь: 1 пациент - много приёмов
        public ICollection<Appointment>? Appointments { get; set; }
    }
}
