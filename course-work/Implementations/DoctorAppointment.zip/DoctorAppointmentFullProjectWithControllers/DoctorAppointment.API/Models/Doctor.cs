﻿using System.ComponentModel.DataAnnotations;

namespace DoctorAppointment.API.Models
{
    public class Doctor
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string LastName { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string Specialty { get; set; } = string.Empty;

        [Required]
        public DateTime DateOfHire { get; set; }

        [Required]
        public double Salary { get; set; }

        [MaxLength(100)]
        public string? OfficeAddress { get; set; }

        // Связь: 1 доктор - много приёмов
        public ICollection<Appointment>? Appointments { get; set; }
    }
}
